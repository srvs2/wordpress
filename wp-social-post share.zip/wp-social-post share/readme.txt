=== WP Social Post Share ===
Contributors: Abhishek Srivastva
Version: 1.0
Tags: social,social share, social post, content share
Requires at least: 3.0.1
Tested up to: 5.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

=== Description ===
This plugin works with worpress post type,custom post type without using shortcode.

== Installation ==
1. Upload Social Content Share from wordpress admin panel
2. Activate the plugin through the 'Plugins' menu in WordPress
3. After Activation go to admin menu click on social tab 
4. you will get Social Options page and click on checkbox for your choice do save changes
3. On frontend page you can find social icon below post 
4. Click on icon like facebook , twitter and new tab will be open
5. Once you click on share button your post will be share.
6. No shortcode required



== Frequently Asked Questions ==



== Screenshots ==





== Changelog ==





== Upgrade Notice ==





== Arbitrary section ==

 





